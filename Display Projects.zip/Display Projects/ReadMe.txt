This website has 4 webpages.
The html file of the website is in the "Main" folder.
The images are in the "Main/images" directory.
The code is fully uploaded in my GitHub Page, You can download it using this URL -> "https://daddy1313.github.io/Basic-Tools/Main/index.html"
The form for the GuideLine is in the folder with both pdf and docx format.
Thanks for reading.
